// Public (no login) endpoints for the marketing pages.
//   GET/POST /api/site/school-info  -> live school plan: trial days + price tiers
//   GET      /api/site/config       -> ad settings (what the blog and the app should show)
//   GET      /api/site/showcase     ?kind=school|centre  -> schools & centres the owner has approved for the site
//   GET      /api/site/showcase-logo?id=<school id>        -> that school's own logo (approved ones only)
//   POST     /api/site/school-demo  { name, school, phone, email, students, message } -> emails the admin
import { sendOk, sendErr, sendMethodNotAllowed, setCors, readBody } from "../_helpers/response.js";
import { rateLimitOk } from "../_helpers/guard.js";
import { getPricing } from "../_helpers/pricing.js";
import { getAdsConfig } from "../_helpers/adsConfig.js";
import { getSettings as getPartnerSettings } from "../_helpers/partners.js";
import { getShopCatalog, publicItem } from "../_helpers/shopItems.js";
import { getSupabase } from "../_helpers/supabase.js";
import { notifyAdmin } from "../_helpers/mail.js";
import { insertRow, supabaseEnabled } from "../_helpers/supabase.js";

const clean = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").replace(/\s+/g, " ").trim().slice(0, n);

export default async function handler(req, res) {
  setCors(res);
  if (req.method === "OPTIONS") return res.status(200).end();
  const op = String(req.query?.op || "");

  // Link previews: crawlers (WhatsApp, Facebook, X, Telegram) do not run the app, so /partner and /school are served
  // as the normal page with their own preview title, text and picture swapped into the <head>.
  if (op === "page") {
    const PAGES = {
      partner: { title: "Partner with EliteScholars: earn commission on every student", desc: "Share your own link and earn commission each time a student you bring goes Pro. Free to join, track every referral.", img: "og/og-partner.jpg", path: "/partner" },
      school: { title: "EliteScholars for Schools: exam prep, assignments and progress", desc: "CBT practice, class assignments and progress tracking for every student in your school. Start with a free trial.", img: "og/og-school.jpg", path: "/school" },
      centre: { title: "EliteScholars for Tutorial & JAMB Centres: practice, mock exams and reports", desc: "Keep your students, give them JAMB/WAEC practice between lessons, run mock exam nights and show parents real progress. Free trial for your centre.", img: "og/og-school.jpg", path: "/centre" },
    };
    const pq = String(req.query?.p || "");
    const key = pq === "school" ? "school" : pq === "centre" ? "centre" : "partner";
    const pg = PAGES[key];
    const SITE = "https://elitescholars.site";
    let html = "";
    try {
      const host = String(req.headers["x-forwarded-host"] || req.headers.host || "elitescholars.site").replace(/[^A-Za-z0-9.:-]/g, "");
      const r = await fetch(`https://${host}/index.html`, { headers: { "User-Agent": "es-og-page" } });
      if (r.ok) html = await r.text();
    } catch { /* fall through */ }
    if (!html || !html.includes("</head>")) { res.statusCode = 302; res.setHeader("Location", "/"); return res.end(); }
    const e = (v) => String(v).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
    const setMeta = (attr, name, val) => {
      const re = new RegExp(`<meta\\s+${attr}="${name}"\\s+content="[^"]*"\\s*/?>`, "i");
      const tag = `<meta ${attr}="${name}" content="${e(val)}" />`;
      html = re.test(html) ? html.replace(re, tag) : html.replace("</head>", `${tag}</head>`);
    };
    const multi = (attr, name, val) => { // handles tags written over several lines in index.html
      const re = new RegExp(`<meta\\s+${attr}="${name}"\\s+content="[^"]*"\\s*/?>`, "i");
      if (re.test(html)) html = html.replace(re, `<meta ${attr}="${name}" content="${e(val)}" />`); else setMeta(attr, name, val);
    };
    html = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${e(pg.title)}</title>`);
    multi("name", "description", pg.desc);
    multi("property", "og:title", pg.title); multi("property", "og:description", pg.desc);
    multi("property", "og:url", SITE + pg.path); multi("property", "og:image", `${SITE}/${pg.img}`);
    multi("property", "og:image:alt", pg.title); multi("property", "og:type", "website");
    multi("name", "twitter:title", pg.title); multi("name", "twitter:description", pg.desc); multi("name", "twitter:image", `${SITE}/${pg.img}`);
    html = html.replace(/<link rel="canonical" href="[^"]*"\s*\/?>/i, `<link rel="canonical" href="${SITE}${pg.path}" />`);
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "public, max-age=300, s-maxage=3600, stale-while-revalidate=86400");
    return res.end(html);
  }

  if (op === "config") {
    res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
    let partnerRate = 40;
    try { if (supabaseEnabled()) partnerRate = (await getPartnerSettings()).defaultRate || 40; } catch { /* default */ }
    return sendOk(res, { ads: await getAdsConfig(), partnerRate });
  }

  if (op === "shop") {
    res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
    const where = ["landing", "blog", "app"].includes(String(req.query?.where)) ? String(req.query.where) : "landing";
    let items = [];
    try { items = (await getShopCatalog()).filter((i) => i.show[where]).slice(0, 24).map(publicItem); } catch { /* none */ }
    return sendOk(res, { items });
  }

  if (op === "groups") {
    res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
    const { loadGroups, DEFAULT_GROUPS } = await import("../_helpers/groupChats.js");
    let list = DEFAULT_GROUPS;
    try { list = await loadGroups(getSupabase()); } catch { /* defaults */ }
    return sendOk(res, { groups: list.filter((g) => g.on !== false).map((g) => ({ id: g.id, name: g.name, url: g.url, audiences: g.audiences || [] })) });
  }

  if (op === "blog-covers") {
    res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
    let map = {};
    try { const { data } = await getSupabase().from("settings").select("value").eq("key", "blog_covers").maybeSingle(); map = (data && data.value) || {}; } catch { /* none */ }
    const out = {};
    for (const [k, v] of Object.entries(map)) out[k] = `/api/site/media?id=${encodeURIComponent(v)}`;
    return sendOk(res, { covers: out });
  }

  if (op === "media") {
    // Only images uploaded from Admin → Shop / Blog covers are public.
    const id = String(req.query?.id || "");
    if (!/^[0-9a-f-]{36}$/i.test(id) || !supabaseEnabled()) return res.status(404).end();
    const { data } = await getSupabase().from("media").select("data,email").eq("id", id).maybeSingle();
    const m = data && (data.email === "shop-admin" || data.email === "blog-admin") && /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(data.data);
    if (!m) return res.status(404).end();
    res.setHeader("Content-Type", m[1]);
    res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    return res.status(200).send(Buffer.from(m[2], "base64"));
  }

  // Schools and centres that chose "show us on the site" AND were approved by the owner in Admin.
  if (op === "showcase") {
    res.setHeader("Cache-Control", "public, max-age=120, s-maxage=300, stale-while-revalidate=600");
    const sb = getSupabase();
    if (!sb) return sendOk(res, { items: [] });
    const kind = String(req.query?.kind || "");
    let q = sb.from("schools").select("id,name,kind,state,city,showcase_tagline,logo,showcase_at").eq("showcase_status", "approved").order("showcase_at", { ascending: false }).limit(60);
    if (kind === "school" || kind === "centre") q = q.eq("kind", kind);
    const { data } = await q;
    return sendOk(res, { items: (data || []).map((s) => ({ id: s.id, name: s.name, kind: s.kind || "school", state: s.state || "", city: s.city || "", tagline: s.showcase_tagline || "", hasLogo: !!s.logo })) });
  }
  if (op === "showcase-logo") {
    const sb = getSupabase();
    const id = String(req.query?.id || "");
    if (!sb || !/^[0-9a-f-]{36}$/i.test(id)) return res.status(404).end();
    const { data: s } = await sb.from("schools").select("logo,showcase_status").eq("id", id).maybeSingle();
    const m = s && s.showcase_status === "approved" && typeof s.logo === "string" ? s.logo.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/) : null;
    if (!m) return res.status(404).end();
    res.setHeader("Content-Type", m[1]);
    res.setHeader("Cache-Control", "public, max-age=3600, s-maxage=86400, stale-while-revalidate=604800");
    return res.status(200).send(Buffer.from(m[2], "base64"));
  }

  if (op === "school-info") {
    res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
    const p = await getPricing();
    return sendOk(res, { trialDays: p.school.trialDays, period: p.school.period, tiers: p.school.tiers, centre: p.centre });
  }

  if (op === "school-demo") {
    if (req.method !== "POST") return sendMethodNotAllowed(res);
    if (!(await rateLimitOk(req, res, "school-demo", 5, 3600))) return;
    const b = readBody(req);
    const name = clean(b.name, 80), school = clean(b.school, 120), phone = clean(b.phone, 30), email = clean(b.email, 120);
    const students = clean(b.students, 20), message = clean(b.message, 600);
    if (b.website) return sendOk(res, {}); // honeypot: bots fill this, people never see it
    if (name.length < 2 || school.length < 2) return sendErr(res, "Please add your name and your school's name.");
    if (!/^\+?[0-9 ()-]{7,20}$/.test(phone) && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return sendErr(res, "Add a phone number or an email so we can reach you.");
    try { if (supabaseEnabled()) await insertRow("events", { type: "school_demo_request", payload: { name, school, phone, email, students, message } }); } catch { /* logging only */ }
    try {
      await notifyAdmin(`School demo request: ${school}`, `${name} from ${school} wants a demo.`, {
        emoji: "🏫",
        rows: [["Name", name], ["School", school], ["Phone", phone || "-"], ["Email", email || "-"], ["Students", students || "-"], ["Message", message || "-"]],
      });
    } catch { /* admin email is best effort */ }
    return sendOk(res, { message: "Thanks! We'll contact you within 24 hours." });
  }
  return sendErr(res, "Unknown route.", 404);
}
