import React, { useState, useEffect } from 'react';
import { ACHIEVEMENTS } from '../utils/constants';
import { loadAchievements, saveAchievements } from '../utils/storage';
import { getPremiumData } from '../utils/premium';
import { fetchShopData, fetchPremiumStatus } from '../utils/profileApi';
import { initiatePayment } from '../utils/profileApi';
import ProCards from './ProCards';
import GroupPlans from './GroupPlans';
import Icon, { EmojiIcon } from './Icon';

const CATEGORY_ICON = {
  Notes: 'pen',
  'Cheat Sheet': 'ruler',
  Bundle: 'cap',
  Guide: 'bulb',
  Comics: 'bookOpen',
};

// ── Fallback SVG when image is missing ───────────────────────────────────────
function ShopItemPlaceholder({ category, color = '#8B5CF6' }) {
  return (
    <div className="shop-item-placeholder" style={{ background: `${color}12`, color }}>
      <Icon name={CATEGORY_ICON[category] || 'shop'} size={26} />
      <span className="shop-item-placeholder-label">{category}</span>
    </div>
  );
}

// ── Secure image URL — only allow our own /shop/ path ────────────────────────
function getImageUrl(filename) {
  if (!filename) return null;
  // Strip any path traversal attempts, allow only filename
  const safe = filename.replace(/[^a-zA-Z0-9._-]/g, '');
  if (!safe || safe !== filename) return null;
  return `/shop/${safe}`;
}

export default function Shop({ userEmail, name, premiumUser, onPremiumActivated }) {
  const [, setLocalPremium] = useState(premiumUser);
  const [shopItems, setShopItems]                 = useState([]);
  const [pricing, setPricing]                     = useState({});
  const [premData, setPremData]                   = useState(getPremiumData(userEmail));
  const [proStatus, setProStatus]                 = useState({ all: false, exams: {}, examsStr: {} });
  const [loadingShop, setLoadingShop]             = useState(true);
  const [buying, setBuying]                       = useState('');
  const [buyErr, setBuyErr]                       = useState('');

  // Pay in-app (Flutterwave); fall back to the old external link if that fails.
  const buyItem = async (item) => {
    if (buying) return;
    setBuyErr(''); setBuying(item.id);
    try {
      const r = await initiatePayment({ email: userEmail, name, item: item.id });
      if (r && r.success && r.paymentLink) { window.location.href = r.paymentLink; return; }
      if (item.link) { window.open(item.link, '_blank', 'noopener'); }
      else setBuyErr((r && r.error) || 'Could not start payment. Try again.');
    } catch {
      if (item.link) window.open(item.link, '_blank', 'noopener');
      else setBuyErr('Network error. Check your connection.');
    }
    setBuying('');
  };

  const FMT = (n) => n?.toLocaleString('en-NG') ?? '0';


  // ── Fetch shop data ────────────────────────────────────────────────────────
  useEffect(() => {
    fetchShopData()
      .then(data => {
        if (data?.items)   setShopItems(data.items);
        if (data?.pricing) setPricing(data.pricing);
      })
      .catch(() => {})
      .finally(() => setLoadingShop(false));
  }, []);

  // ── Check server-side pro status ───────────────────────────────────────
  useEffect(() => {
    if (!userEmail) return;
    fetchPremiumStatus(userEmail).then(data => {
      if (data) setProStatus({ all: !!data.all, exams: data.exams || {}, examsStr: data.examsStr || {} });
      if (data?.isPremium) {
        setLocalPremium(true);
        setPremData({ plan: data.plan, expiresDateStr: data.expiresStr });
      }
    }).catch(() => {});
  }, [userEmail]);

  // ── Payment redirect check ─────────────────────────────────────────────────
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('payment') === 'success' && params.get('plan') !== 'shop' && params.get('email') === userEmail) {
      const plan = params.get('plan') || 'annual';
      setLocalPremium(true);
      if (onPremiumActivated) onPremiumActivated({ plan });
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [userEmail]);

  // ── Shop visited achievement ───────────────────────────────────────────────
  useEffect(() => {
    if (!userEmail) return;
    const existing = loadAchievements(userEmail);
    if (!existing.some((a) => a?.id === 'shopShopper')) {
      saveAchievements([...existing, ACHIEVEMENTS.shopShopper], userEmail);
    }
  }, [userEmail]);




  const regularItems = shopItems.filter((i) => !i.isPremium);
  const categories   = [...new Set(regularItems.map((i) => i.category))];



  return (
    <div className="scr fd shop-page">

      {/* ── Header ── */}
      <div className="shop-header">
        <div className="shop-header-glow" />
        <div className="shop-header-content">
          <div className="shop-title"><EmojiIcon emoji="🛍️" size="1.15em" /> Elite Shop</div>
      </div>
      </div>
      <div className="shop-body">

        {/* ── Pro: one plan per exam (JAMB / WAEC & NECO / GST) ── */}
        <div className="shop-plans-section">
          <div className="shop-plans-card">
            {proStatus.all && (
              <div className="shop-footer-note" style={{ marginBottom: 10 }}>⭐ You have Pro for <b>every exam</b>{premData?.expiresDateStr ? ` until ${premData.expiresDateStr}` : ''}. You can still add time to a single exam below.</div>
            )}
            <ProCards email={userEmail} name={name} pricing={pricing} status={proStatus} />

          </div>
        </div>

        <GroupPlans userEmail={userEmail} name={name} pricing={pricing} />

        {/* ── Shop items ── */}
        {loadingShop ? (
          <div className="shop-loading">
            <div className="shop-loading-spinner" />
            <span>Loading items...</span>
          </div>
        ) : (
          categories.map((cat) => (
            <div key={cat} className="shop-category-section">
              <div className="shop-category-label"><Icon name={CATEGORY_ICON[cat] || 'shop'} size={15} /> {cat}</div>
              <div className="shop-grid">
                {regularItems.filter((i) => i.category === cat).map((item) => {
                  const imgUrl = (typeof item.imageUrl === 'string' && item.imageUrl.startsWith('/api/site/media?id=')) ? item.imageUrl : getImageUrl(item.image);
                  return (
                    <div
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => buyItem(item)}
                      onKeyDown={(e) => { if (e.key === 'Enter') buyItem(item); }}
                      className="shop-item-card"
                    >
                      {/* Image / placeholder */}
                      <div className="shop-item-img">
                        {item.badge && (
                          <span className="shop-item-badge">{item.badge}</span>
                        )}
                        {imgUrl ? (
                          <img
                            src={imgUrl}
                            alt={item.title}
                            className="shop-item-img-tag"
                            loading="lazy"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.nextSibling.style.display = 'flex';
                            }}
                          />
                        ) : null}
                        <ShopItemPlaceholder
                          category={item.category}
                          style={{ display: imgUrl ? 'none' : 'flex' }}
                        />
                      </div>

                      {/* Body */}
                      <div className="shop-item-body">
                        <div className="shop-item-title">{item.title}</div>
                        <div className="shop-item-desc">{item.description}</div>
                        <div className="shop-item-footer">
                          <span className="shop-item-price">{item.price}</span>
                          <span className="shop-item-buy">{buying === item.id ? 'Opening…' : 'Buy →'}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}

        {buyErr && <div className="shop-footer-note" style={{ color: '#f87171' }}>{buyErr}</div>}
        <div className="shop-footer-note">
          🔒 All payments are secured by Flutterwave
        </div>

      </div>


    </div>
  );
}