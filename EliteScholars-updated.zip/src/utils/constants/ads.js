// ============================================================================
// constants/ads.js — All ad-related settings
// ============================================================================

export const SHOW_ADS = false;

export const SHOW_POPOVER_AD   = false;
export const POPOVER_AD_URL    = 'https://fixesconsessionconsession.com/63/ce/c2/63cec2ed9aad27f090a8f39c2b6d7469';
export const POPOVER_AD_SCRIPT = 'https://fixesconsessionconsession.com/63/ce/c2/63cec2ed9aad27f090a8f39c2b6d7469.js';

export const PUBLISHER_AD_ENABLED = false;
export const PUBLISHER_AD_SCRIPT  = 'https://pl29020764.effectivecpmnetwork.com/ec0487cde03d79b75629df8828d753f9/invoke.js';

export const AD_EVERY_NTH_SUBHEADING = 2;
export const MAX_ADS_PER_PAGE        = 5;

export const AFFILIATE_ADS_ENABLED = false;
export const AFFILIATE_ADS = [
  {
  image:       '/images/ads/palmpay-students.jpg',
  title:       'Open Your PalmPay Account Today!',
  description: 'No more “please wait” moments. Receive money from parents faster, buy airtime instantly, and pay for what you need without stress.',
  link:        'https://info.palmpay.com/sP7ZEQrG',
  cta:         'Create PalmPay Account →',
  audiences:   ['all'],
},

];

export const CUSTOM_AD_ENABLED = false;
export const CUSTOM_ADS = [
  {
    image:       '/images/ads/doxiee-affiliate-masterclass.jpg',
    title:       'Earn ₦150k from Affiliate Marketing',
    description: 'Take the bold step today and start earning while you learn.',
    link:        'https://wa.me/2347052122350?text=Hello%2C%20I%20need%20the%20Affiliate%20Masterclass.%20I%20was%20referred%20by%20EliteScholars',
    cta:         'Join Masterclass →',
    audiences:   ['all'],
  },
  {
    image:       '/images/ads/resumeefy-student.jpg',
    title:       '50+ Remote Roles for Students!',
    description: 'Get a professional student resume today for just ₦5k and start getting offers.',
    link:        'https://wa.me/2349093788218?text=Hello%2C%20I%20need%20the%20Student%20Resume%20service.%20I%20was%20referred%20by%20EliteScholars',
    cta:         'Get Resume for ₦5k →',
    audiences:   ['all'],
  },
{
  image:       '/images/ads/volt-victory-accessories.jpg',
  title:       'Power Your Lifestyle!',
  description: 'Shop reliable, stylish, and affordable phone accessories built for every device. Chargers, cases, AirPods, cables, power banks & more.',
  link:        'https://wa.me/2349034878935?text=Hello%2C%20I%20want%20to%20order%20phone%20accessories.%20I%20was%20referred%20by%20EliteScholars',
  cta:         'Order Now →',
  audiences:   ['all'],
},
];
